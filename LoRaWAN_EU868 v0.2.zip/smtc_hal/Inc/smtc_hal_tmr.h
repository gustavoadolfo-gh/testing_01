/**
 * @file      smtc_hal_tmr.h
 *
 * @brief     Board specific package HW timer API definition.
 *
 * Revised BSD License
 * Copyright Semtech Corporation 2020. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Semtech corporation nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SEMTECH CORPORATION BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef SMTC_HAL_TMR_H
#define SMTC_HAL_TMR_H

#ifdef __cplusplus
extern "C" {
#endif
/*
 * -----------------------------------------------------------------------------
 * --- DEPENDENCIES ------------------------------------------------------------
 */

#include <stdint.h>   // C99 types
#include <stdbool.h>  // bool type

/*
 * -----------------------------------------------------------------------------
 * --- PUBLIC MACROS -----------------------------------------------------------
 */

/*
 * -----------------------------------------------------------------------------
 * --- PUBLIC CONSTANTS --------------------------------------------------------
 */

/*
 * -----------------------------------------------------------------------------
 * --- PUBLIC TYPES ------------------------------------------------------------
 */

/**
 * @brief Timer IRQ handling data context
 */
typedef struct hal_tmr_irq_s
{
    void* context;
    void ( *callback )( void* context );
} hal_tmr_irq_t;

/*
 * -----------------------------------------------------------------------------
 * --- PUBLIC FUNCTIONS PROTOTYPES ---------------------------------------------
 */

/**
 *  @brief Initializes the MCU TMR peripheral
 */
void hal_tmr_init( void );

/**
 * @brief Starts the provided timer objet for the given time
 *
 * @param [in] milliseconds Number of milliseconds
 * @param [in] tmr_irq      Timer IRQ handling data ontext
 */
void hal_tmr_start( const uint32_t milliseconds, const hal_tmr_irq_t* tmr_irq );

/**
 * @brief Starts the provided timer objet for the given time
 */
void hal_tmr_stop( void );

/**
 * @brief Returns the current TMR time in milliseconds
 *
 * @remark is used to timestamp radio events (end of TX), will also be used for
 *
 * @returns tmr_time_ms Current TMR time in milliseconds wraps every 49 days
 */
uint32_t hal_tmr_get_time_ms( void );

/**
 * @brief Enables timer interrupts (HW timer only)
 */
void hal_tmr_irq_enable( void );

/**
 * @brief Disables timer interrupts (HW timer only)
 */
void hal_tmr_irq_disable( void );

#ifdef __cplusplus
}
#endif

#endif  // SMTC_HAL_TMR_H

/* --- EOF ------------------------------------------------------------------ */
