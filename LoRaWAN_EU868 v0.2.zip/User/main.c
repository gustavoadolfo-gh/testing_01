#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <limits.h>

#include "lorawan_commissioning.h"
#include "lr1121_modem_board.h"
#include "lr1121_modem_modem.h"
#include "lr1121_modem_system.h"
#include "apps_utilities.h"
#include "lr1121_modem_helper.h"
#include "lr1121_modem_system_types.h"
#include "dht11.h"
#include "delay.h"

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE MACROS ----------------------------------------------------------
 */

#define xstr( a ) str( a )
#define str( a ) #a

/**
 * @brief Print a diagnostic message when a modem command fails.
 *
 * Important:
 * This macro only prints the error. It does not stop the calling sequence.
 * Critical initialization code should use explicit return-code checks.
 */
#define ASSERT_SMTC_MODEM_RC( rc_func )                                                   \
    do                                                                                   \
    {                                                                                    \
        const lr1121_modem_response_code_t rc = ( rc_func );                            \
                                                                                         \
        if( rc == LR1121_MODEM_RESPONSE_CODE_NOT_INITIALIZED )                          \
        {                                                                                \
            HAL_DBG_TRACE_ERROR(                                                         \
                "In %s - %s (line %d): %s\n",                                           \
                __FILE__,                                                                \
                __func__,                                                                \
                __LINE__,                                                                \
                xstr( LR1121_MODEM_RESPONSE_CODE_NOT_INITIALIZED ) );                    \
        }                                                                                \
        else if( rc == LR1121_MODEM_RESPONSE_CODE_INVALID )                             \
        {                                                                                \
            HAL_DBG_TRACE_ERROR(                                                         \
                "In %s - %s (line %d): %s\n",                                           \
                __FILE__,                                                                \
                __func__,                                                                \
                __LINE__,                                                                \
                xstr( LR1121_MODEM_RESPONSE_CODE_INVALID ) );                            \
        }                                                                                \
        else if( rc == LR1121_MODEM_RESPONSE_CODE_BUSY )                                \
        {                                                                                \
            HAL_DBG_TRACE_ERROR(                                                         \
                "In %s - %s (line %d): %s\n",                                           \
                __FILE__,                                                                \
                __func__,                                                                \
                __LINE__,                                                                \
                xstr( LR1121_MODEM_RESPONSE_CODE_BUSY ) );                               \
        }                                                                                \
        else if( rc == LR1121_MODEM_RESPONSE_CODE_FAIL )                                \
        {                                                                                \
            HAL_DBG_TRACE_ERROR(                                                         \
                "In %s - %s (line %d): %s\n",                                           \
                __FILE__,                                                                \
                __func__,                                                                \
                __LINE__,                                                                \
                xstr( LR1121_MODEM_RESPONSE_CODE_FAIL ) );                               \
        }                                                                                \
        else if( rc == LR1121_MODEM_RESPONSE_CODE_NO_TIME )                             \
        {                                                                                \
            HAL_DBG_TRACE_WARNING(                                                       \
                "In %s - %s (line %d): %s\n",                                           \
                __FILE__,                                                                \
                __func__,                                                                \
                __LINE__,                                                                \
                xstr( LR1121_MODEM_RESPONSE_CODE_NO_TIME ) );                            \
        }                                                                                \
        else if( rc == LR1121_MODEM_RESPONSE_CODE_NO_EVENT )                            \
        {                                                                                \
            HAL_DBG_TRACE_INFO(                                                          \
                "In %s - %s (line %d): %s\n",                                           \
                __FILE__,                                                                \
                __func__,                                                                \
                __LINE__,                                                                \
                xstr( LR1121_MODEM_RESPONSE_CODE_NO_EVENT ) );                           \
        }                                                                                \
    } while( 0 )

/**
 * @brief Watchdog reload period during sleep.
 *
 * The value must remain lower than the effective hardware-watchdog period.
 */
#define WATCHDOG_RELOAD_PERIOD_MS 20000UL

/**
 * @brief Periodical application uplink delay.
 */
#define PERIODICAL_UPLINK_DELAY_S 300UL

/**
 * @brief Dedicated LoRaWAN LCTT certification build.
 */
#define LCTT_CERTIFICATION_MODE 1

#define EXTI_BUTTON PC_13

/**
 * @brief Maximum LoRaWAN application payload buffer size.
 */
#define LORAWAN_APP_DATA_MAX_SIZE 242U

/**
 * @brief LoRaWAN regulatory region.
 * One of:
 * LR1121_LORAWAN_REGION_AS923_GRP1
 * LR1121_LORAWAN_REGION_AS923_GRP2
 * LR1121_LORAWAN_REGION_AS923_GRP3
 * LR1121_LORAWAN_REGION_AS923_GRP4
 * LR1121_LORAWAN_REGION_AU915
 * LR1121_LORAWAN_REGION_CN470
 * LR1121_LORAWAN_REGION_EU868
 * LR1121_LORAWAN_REGION_IN865
 * LR1121_LORAWAN_REGION_KR920
 * LR1121_LORAWAN_REGION_RU864
 * LR1121_LORAWAN_REGION_US915
 */
#define LORAWAN_REGION_USED LR1121_LORAWAN_REGION_EU868

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE CONSTANTS -------------------------------------------------------
 */

#if( !USE_LR11XX_CREDENTIALS )

static const uint8_t user_join_eui[8]  = LORAWAN_JOIN_EUI;
static const uint8_t user_dev_eui[8]   = LORAWAN_DEVICE_EUI;
static const uint8_t user_nwk_key[16]  = LORAWAN_NWK_KEY;
static const uint8_t user_app_key[16]  = LORAWAN_APP_KEY;

#endif

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE VARIABLES -------------------------------------------------------
 */

#if( USE_LR11XX_CREDENTIALS )

static uint8_t chip_eui[8] = { 0 };
static uint8_t chip_pin[4] = { 0 };

#endif

extern lr1121_t lr1121;

extern uint8_t Data[5];
extern int flag;

static volatile bool user_button_is_press = false;

/**
 * Set from the LR1121 EVENT GPIO interrupt.
 *
 * The interrupt callback does not access SPI, print messages or process modem
 * events. Actual processing is performed from the main loop.
 */
static volatile bool lr1121_event_pending = false;

static uint16_t uplink_counter    = 0;
static uint16_t confirmed_counter = 0;
static bool uplink_sending        = false;

static uint32_t join_fail_counter = 0;

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE FUNCTIONS DECLARATION -------------------------------------------
 */

static void user_button_callback( void* context );

static void lr1121_event_callback( void* context );

static void event_process( void* context );

static void send_uplinks_counter_on_port( uint8_t port );

static lr1121_modem_response_code_t send_frame(
    const uint8_t* tx_frame_buffer,
    const uint8_t tx_frame_buffer_size,
    uint8_t port,
    const lr1121_modem_uplink_type_t tx_confirmed );

static bool print_lr1121_modem_version( const void* context );

static bool print_lr1121_system_version( const void* context );

static bool print_all_lr1121_versions( const void* context );

static bool configure_modem_after_reset( const void* context );

static bool configure_lctt_certification_mode( const void* context );

static bool has_lr1121_event_pending( void );


void read_DHT11_data( void );

void my_test( void );

/*
 * -----------------------------------------------------------------------------
 * --- PUBLIC FUNCTIONS DEFINITION ---------------------------------------------
 */

int main( void )
{
    hal_mcu_init();
    hal_mcu_init_periph();

#if !LCTT_CERTIFICATION_MODE
    /*
     * Avoid blocking LED sequences in the certification build.
     */
    leds_blink(
        LED_ALL_MASK,
        250,
        4,
        true );
#endif

    HAL_DBG_TRACE_MSG( "\n\n" );

    HAL_DBG_TRACE_INFO(
        "===== LR1121 LoRaWAN LCTT Certification v0.2 =====\n\n" );

    /*
     * Prevent callbacks while installing the GPIO configurations.
     */
    hal_mcu_disable_irq();

    hal_gpio_irq_t nucleo_blue_button =
    {
        .pin      = EXTI_BUTTON,
        .context  = NULL,
        .callback = user_button_callback,
    };

    hal_gpio_init_in(
        EXTI_BUTTON,
        HAL_GPIO_PULL_MODE_NONE,
        HAL_GPIO_IRQ_MODE_FALLING,
        &nucleo_blue_button );

    /*
     * The LR1121 GPIO callback must remain short.
     *
     * It only marks an event pending and returns from the EXTI handler.
     */
    hal_gpio_irq_t event_callback =
    {
        .pin      = lr1121.event.pin,
        .context  = &lr1121,
        .callback = lr1121_event_callback,
    };

    hal_gpio_init_in(
        lr1121.event.pin,
        HAL_GPIO_PULL_MODE_NONE,
        HAL_GPIO_IRQ_MODE_RISING,
        &event_callback );

    /*
     * Remove stale events before enabling the interrupt.
     *
     * A failure is reported, but initialization continues so the application
     * can receive the RESET event generated by the explicit reboot below.
     */
    {
        const lr1121_modem_response_code_t rc =
            lr1121_modem_board_event_flush(
                &lr1121 );

        if( rc == LR1121_MODEM_RESPONSE_CODE_NO_EVENT )
        {
            HAL_DBG_TRACE_INFO(
                "Event queue already empty\n" );
        }
        else if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
        {
            HAL_DBG_TRACE_WARNING(
                "Event flush returned rc=%u\n",
                ( unsigned int ) rc );
        }
    }

    hal_mcu_enable_irq();

#if !LCTT_CERTIFICATION_MODE
    leds_blink(
        LED_TX_MASK,
        100,
        20,
        true );
#endif

    HAL_DBG_TRACE_MSG(
        "Initialization done\n\n" );

    /*
     * Generate a clean Modem-E RESET event.
     *
     * The RESET event will be processed later from the main loop.
     */
    {
        const lr1121_modem_response_code_t rc =
            lr1121_modem_system_reboot(
                &lr1121,
                false );

        if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
        {
            HAL_DBG_TRACE_ERROR(
                "LR1121 reboot failed, rc=%u\n",
                ( unsigned int ) rc );
        }
    }

    while( 1 )
    {
        bool process_lr1121_event = false;

        /*
         * Copy and clear the event flag atomically.
         */
        CRITICAL_SECTION_BEGIN();

        if( lr1121_event_pending == true )
        {
            lr1121_event_pending = false;
            process_lr1121_event = true;
        }

        CRITICAL_SECTION_END();

        /*
         * Also inspect the physical EVENT line. This protects against an edge
         * that occurred while the callback was temporarily unavailable.
         */
        if( lr1121_modem_board_read_event_line(
                &lr1121 ) == true )
        {
            process_lr1121_event = true;
        }

        if( process_lr1121_event == true )
        {
            event_process(
                &lr1121 );
        }

        if( user_button_is_press == true )
        {
            user_button_is_press = false;

            HAL_DBG_TRACE_MSG(
                "Button pushed\n\n" );

#if LCTT_CERTIFICATION_MODE

            lr1121_modem_certification_mode_t certification_mode =
                LR1121_MODEM_CERTIFICATION_MODE_DISABLE;

            const lr1121_modem_response_code_t rc =
                lr1121_modem_get_certification_mode(
                    &lr1121,
                    &certification_mode );

            if( rc == LR1121_MODEM_RESPONSE_CODE_OK )
            {
                print_certification(
                    certification_mode );
            }
            else
            {
                HAL_DBG_TRACE_ERROR(
                    "Unable to read Certification Mode, rc=%u\n",
                    ( unsigned int ) rc );
            }

#else

            lr1121_modem_lorawan_status_bitmask_t modem_status = 0;

            const lr1121_modem_response_code_t rc =
                lr1121_modem_get_status(
                    &lr1121,
                    &modem_status );

            if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
            {
                HAL_DBG_TRACE_ERROR(
                    "Unable to read modem status, rc=%u\n",
                    ( unsigned int ) rc );
            }
            else if( ( modem_status &
                       LR1121_LORAWAN_JOINED ) != 0 )
            {
                if( uplink_sending == false )
                {
                    send_uplinks_counter_on_port(
                        102 );
                }
                else
                {
                    HAL_DBG_TRACE_PRINTF(
                        "An uplink is already pending\n" );
                }
            }
            else
            {
                HAL_DBG_TRACE_PRINTF(
                    "The device has not joined the network\n" );
            }

#endif
        }

        hal_watchdog_reload();

        /*
         * Protect the decision to enter low power.
         *
         * Do not enter STOP mode if:
         * - the software event flag is set;
         * - the LR1121 EVENT line is asserted;
         * - an EXTI interrupt remains pending;
         * - the user button requires processing.
         */
        hal_mcu_disable_irq();

        if( ( user_button_is_press == false ) &&
            ( lr1121_event_pending == false ) &&
            ( lr1121_modem_board_read_event_line(
                  &lr1121 ) == false ) &&
            ( hal_gpio_is_pending_irq() == false ) )
        {
            hal_watchdog_reload();

            hal_mcu_set_sleep_for_ms(
                WATCHDOG_RELOAD_PERIOD_MS );
        }

        hal_watchdog_reload();
        hal_mcu_enable_irq();
    }
}

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE FUNCTIONS DEFINITION --------------------------------------------
 */

static void lr1121_event_callback( void* context )
{
    ( void ) context;

    /*
     * No SPI, UART, delay or modem command is allowed here.
     *
     * This callback executes from the GPIO EXTI interrupt.
     */
    lr1121_event_pending = true;
}

static bool has_lr1121_event_pending( void )
{
    bool pending;

    CRITICAL_SECTION_BEGIN();

    pending = lr1121_event_pending;

    CRITICAL_SECTION_END();

    if( lr1121_modem_board_read_event_line(
            &lr1121 ) == true )
    {
        pending = true;
    }

    return pending;
}

static bool print_lr1121_modem_version( const void* context )
{
    lr1121_modem_version_t version = { 0 };

    const lr1121_modem_response_code_t rc =
        lr1121_modem_get_modem_version(
            context,
            &version );

    if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
    {
        HAL_DBG_TRACE_ERROR(
            "Unable to read Modem-E version, rc=%u\n",
            ( unsigned int ) rc );

        return false;
    }

    HAL_DBG_TRACE_MSG(
        "\n===== LR1121 MODEM VERSION =====\n" );

    HAL_DBG_TRACE_PRINTF(
        "USE CASE : %u\n",
        ( unsigned int ) version.use_case );

    HAL_DBG_TRACE_PRINTF(
        "MODEM-E  : %u.%u.%u\n",
        ( unsigned int ) version.modem_major,
        ( unsigned int ) version.modem_minor,
        ( unsigned int ) version.modem_patch );

    HAL_DBG_TRACE_PRINTF(
        "LBM      : %u.%u.%u\n",
        ( unsigned int ) version.lbm_major,
        ( unsigned int ) version.lbm_minor,
        ( unsigned int ) version.lbm_patch );

    HAL_DBG_TRACE_MSG(
        "================================\n\n" );

    if( version.use_case != 5U )
    {
        HAL_DBG_TRACE_WARNING(
            "Unexpected Modem-E use case: %u, expected 5\n",
            ( unsigned int ) version.use_case );
    }

    return true;
}

static bool print_lr1121_system_version( const void* context )
{
    lr1121_modem_system_version_t version = { 0 };

    const lr1121_modem_response_code_t rc =
        lr1121_modem_system_get_version(
            context,
            &version );

    if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
    {
        HAL_DBG_TRACE_ERROR(
            "Unable to read LR1121 system version, rc=%u\n",
            ( unsigned int ) rc );

        return false;
    }

    HAL_DBG_TRACE_MSG(
        "\n===== LR1121 SYSTEM VERSION =====\n" );

    HAL_DBG_TRACE_PRINTF(
        "SYSTEM HW   : 0x%02X\n",
        ( unsigned int ) version.hw );

    HAL_DBG_TRACE_PRINTF(
        "SYSTEM TYPE : 0x%02X\n",
        ( unsigned int ) version.type );

    HAL_DBG_TRACE_PRINTF(
        "SYSTEM FW   : 0x%04X\n",
        ( unsigned int ) version.fw );

    HAL_DBG_TRACE_MSG(
        "=================================\n\n" );

    /* Modem-E 2.x reports system type 0x05 on this LR1121. */
    if( ( version.type !=
          LR1121_MODEM_SYSTEM_VERSION_TYPE_LR1121 ) &&
        ( version.type != 0x05U ) )
    {
        HAL_DBG_TRACE_WARNING(
            "Unexpected LR1121 system type: 0x%02X\n",
            ( unsigned int ) version.type );
    }
    else
    {
        HAL_DBG_TRACE_INFO(
            "Valid LR1121 system type detected: 0x%02X\n",
            ( unsigned int ) version.type );
    }

    return true;
}

static bool print_all_lr1121_versions( const void* context )
{
    if( print_lr1121_system_version(
            context ) == false )
    {
        return false;
    }

    if( print_lr1121_modem_version(
            context ) == false )
    {
        return false;
    }

    return true;
}

static bool configure_lctt_certification_mode(
    const void* context )
{
#if LCTT_CERTIFICATION_MODE

    lr1121_modem_certification_mode_t certification_mode =
        LR1121_MODEM_CERTIFICATION_MODE_DISABLE;

    lr1121_modem_response_code_t rc =
        lr1121_modem_get_certification_mode(
            context,
            &certification_mode );

    if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
    {
        HAL_DBG_TRACE_ERROR(
            "Unable to read Certification Mode, rc=%u\n",
            ( unsigned int ) rc );

        return false;
    }

    print_certification(
        certification_mode );

    if( certification_mode !=
        LR1121_MODEM_CERTIFICATION_MODE_ENABLE )
    {
        HAL_DBG_TRACE_INFO(
            "###### ===== ENABLING LCTT CERTIFICATION MODE ==== ######\n\n" );

        /*
         * Enabling Certification Mode starts the Join procedure.
         *
         * Do not call lr1121_modem_join() afterwards.
         */
        rc = lr1121_modem_set_certification_mode(
            context,
            LR1121_MODEM_CERTIFICATION_MODE_ENABLE );

        if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
        {
            HAL_DBG_TRACE_ERROR(
                "Unable to enable Certification Mode, rc=%u\n",
                ( unsigned int ) rc );

            return false;
        }

        HAL_DBG_TRACE_INFO(
            "Certification mode enabled - JOIN managed by Modem-E\n\n" );
    }
    else
    {
        HAL_DBG_TRACE_INFO(
            "###### ===== CERTIFICATION MODE ALREADY ENABLED ==== ######\n\n" );

        /*
         * Certification Mode is persistent and already manages the Join.
         *
         * Do not send a duplicate lr1121_modem_join() command.
         */
    }

#else

    ( void ) context;

#endif

    return true;
}

static bool configure_modem_after_reset(
    const void* context )
{
    lr1121_modem_response_code_t rc;

    /*
     * LFCLK and crystal error are intentionally not configured here.
     *
     * They are already configured by lr1121_modem_board_init(). Keeping one
     * owner avoids duplicate commands and conflicting crystal-error values.
     */

    if( print_all_lr1121_versions(
            context ) == false )
    {
        return false;
    }

    /*
     * Read the crashlog only after version queries have completed.
     */
    get_and_print_crashlog(
        context );

#if( !USE_LR11XX_CREDENTIALS )

    HAL_DBG_TRACE_INFO(
        "###### ===== LR1121 AppEUI/JoinEUI and DevEUI ==== ######\n\n" );

    rc = lr1121_modem_set_dev_eui(
        context,
        user_dev_eui );

    if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
    {
        HAL_DBG_TRACE_ERROR(
            "Set DevEUI failed, rc=%u\n",
            ( unsigned int ) rc );

        return false;
    }

    rc = lr1121_modem_set_join_eui(
        context,
        user_join_eui );

    if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
    {
        HAL_DBG_TRACE_ERROR(
            "Set JoinEUI failed, rc=%u\n",
            ( unsigned int ) rc );

        return false;
    }

    rc = lr1121_modem_set_app_key(
        context,
        user_app_key );

    if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
    {
        HAL_DBG_TRACE_ERROR(
            "Set AppKey failed, rc=%u\n",
            ( unsigned int ) rc );

        return false;
    }

    rc = lr1121_modem_set_nwk_key(
        context,
        user_nwk_key );

    if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
    {
        HAL_DBG_TRACE_ERROR(
            "Set NwkKey failed, rc=%u\n",
            ( unsigned int ) rc );

        return false;
    }

    {
        uint8_t temporary_pin[4] = { 0 };

        print_lorawan_credentials(
            user_dev_eui,
            user_join_eui,
            temporary_pin,
            USE_LR11XX_CREDENTIALS );
    }

#else

    {
        uint8_t temporary_join_eui[8] = { 0 };

        rc = lr1121_modem_system_read_uid(
            context,
            chip_eui );

        if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
        {
            HAL_DBG_TRACE_ERROR(
                "Read chip EUI failed, rc=%u\n",
                ( unsigned int ) rc );

            return false;
        }

        rc = lr1121_modem_system_read_pin(
            context,
            chip_pin );

        if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
        {
            HAL_DBG_TRACE_ERROR(
                "Read chip PIN failed, rc=%u\n",
                ( unsigned int ) rc );

            return false;
        }

        rc = lr1121_modem_get_join_eui(
            context,
            temporary_join_eui );

        if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
        {
            HAL_DBG_TRACE_ERROR(
                "Read JoinEUI failed, rc=%u\n",
                ( unsigned int ) rc );

            return false;
        }

        print_lorawan_credentials(
            chip_eui,
            temporary_join_eui,
            chip_pin,
            USE_LR11XX_CREDENTIALS );
    }

#endif

    rc = lr1121_modem_set_region(
        context,
        LORAWAN_REGION_USED );

    if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
    {
        HAL_DBG_TRACE_ERROR(
            "Set LoRaWAN region failed, rc=%u\n",
            ( unsigned int ) rc );

        return false;
    }

    print_lorawan_region(
        LORAWAN_REGION_USED );

#if LCTT_CERTIFICATION_MODE

    if( configure_lctt_certification_mode(
            context ) == false )
    {
        return false;
    }

#else

    HAL_DBG_TRACE_INFO(
        "Periodical uplink (%lu sec)\n\n",
        ( unsigned long ) PERIODICAL_UPLINK_DELAY_S );

    rc = lr1121_modem_join(
        context );

    if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
    {
        HAL_DBG_TRACE_ERROR(
            "Join command failed, rc=%u\n",
            ( unsigned int ) rc );

        return false;
    }

    HAL_DBG_TRACE_INFO(
        "###### ===== JOINING ==== ######\n\n" );

#endif

    return true;
}

static void event_process( void* context )
{
    while( true )
    {
        lr1121_modem_event_fields_t current_event = { 0 };

        const lr1121_modem_response_code_t rc_event =
            lr1121_modem_get_event(
                context,
                &current_event
            );

        if( rc_event == LR1121_MODEM_RESPONSE_CODE_NO_EVENT )
        {
            break;
        }

        if( rc_event == LR1121_MODEM_RESPONSE_CODE_BUSY )
        {
            /*
             * Do not issue more commands while Modem-E is busy.
             * Retry from the main loop.
             */
            lr1121_event_pending = true;
            break;
        }

        if( rc_event != LR1121_MODEM_RESPONSE_CODE_OK )
        {
            HAL_DBG_TRACE_ERROR(
                "lr1121_modem_get_event failed, rc=%u\n",
                ( unsigned int ) rc_event
            );
            break;
        }

        if( current_event.missed_events_count != 0U )
        {
            HAL_DBG_TRACE_WARNING(
                "Missed modem events: type=0x%02X, count=%u\n",
                ( unsigned int ) current_event.event_type,
                ( unsigned int ) current_event.missed_events_count
            );
        }

        switch( current_event.event_type )
        {
            case LR1121_MODEM_LORAWAN_EVENT_RESET:
            {
                HAL_DBG_TRACE_MSG_COLOR(
                    "Event received: RESET\n\n",
                    HAL_DBG_TRACE_COLOR_BLUE
                );

                if( configure_modem_after_reset( context ) == false )
                {
                    HAL_DBG_TRACE_ERROR(
                        "Modem RESET configuration aborted\n"
                    );
                }

                break;
            }
						case LR1121_MODEM_LORAWAN_EVENT_ALARM:
            {
                HAL_DBG_TRACE_MSG_COLOR(
                    "Event received: ALARM\n\n",
                    HAL_DBG_TRACE_COLOR_BLUE
                );            

#if LCTT_CERTIFICATION_MODE
                HAL_DBG_TRACE_INFO(
                    "Application alarm ignored in Certification Mode\n\n"
                );
#else
                send_uplinks_counter_on_port( 101 );

                ASSERT_SMTC_MODEM_RC(
                    lr1121_modem_set_alarm_timer(
                        context,
                        PERIODICAL_UPLINK_DELAY_S
                    )
                );
#endif

                break;
            }

            case LR1121_MODEM_LORAWAN_EVENT_JOINED:
            {
                uint8_t adr_custom_list[16] = { 0 };

                HAL_DBG_TRACE_MSG_COLOR(
                    "Event received: JOINED\n",
                    HAL_DBG_TRACE_COLOR_BLUE
                );

                HAL_DBG_TRACE_INFO(
                    "Modem is now JOINED\n\n"
                );

                ASSERT_SMTC_MODEM_RC(
                    lr1121_modem_set_adr_profile(
                        context,
                        LR1121_MODEM_ADR_PROFILE_NETWORK_SERVER_CONTROLLED,
                        adr_custom_list
                    )
                );

#if LCTT_CERTIFICATION_MODE
                HAL_DBG_TRACE_INFO(
                    "Device joined; Modem-E is ready for LCTT "
                    "commands on FPort 224\n\n"
                );
#else
                send_uplinks_counter_on_port( 101 );

                ASSERT_SMTC_MODEM_RC(
                    lr1121_modem_set_alarm_timer(
                        context,
                        PERIODICAL_UPLINK_DELAY_S
                    )
                );
#endif

                break;
            }

            case LR1121_MODEM_LORAWAN_EVENT_JOIN_FAIL:
            {
                HAL_DBG_TRACE_MSG_COLOR(
                    "Event received: JOINFAIL\n",
										HAL_DBG_TRACE_COLOR_BLUE
								);

                /*
                 * Modem-E/LBM manages the next OTAA attempt and its back-off.
                 * Do not call lr1121_modem_join() from this event.
                 */
                uplink_sending = false;
                break;
            }

            case LR1121_MODEM_LORAWAN_EVENT_TX_DONE:
            {
                const lr1121_modem_tx_done_event_t tx_done_event_data =
                    ( lr1121_modem_tx_done_event_t )
                    ( current_event.data >> 8 );

                HAL_DBG_TRACE_MSG_COLOR(
                    "Event received: TXDONE\n\n",
                    HAL_DBG_TRACE_COLOR_BLUE
                );

                HAL_DBG_TRACE_MSG( "TX DATA: " );

                switch( tx_done_event_data )
                {
                    case LR1121_MODEM_TX_NOT_SENT:
                    {
                        HAL_DBG_TRACE_PRINTF( "NOT SENT" );

                        if( uplink_counter > 0U )
                        {
                            uplink_counter--;
                        }

                        break;
                    }

                    case LR1121_MODEM_CONFIRMED_TX:
                    {
                        HAL_DBG_TRACE_PRINTF( "CONFIRMED - ACK" );
                        confirmed_counter++;
                        break;
                    }

                    case LR1121_MODEM_UNCONFIRMED_TX:
                    {
                        HAL_DBG_TRACE_PRINTF( "UNCONFIRMED" );
                        break;
                    }

                    default:
                    {
                        HAL_DBG_TRACE_PRINTF(
                            "unknown value (%02X)",
                            ( unsigned int ) tx_done_event_data
                        );
                        break;
                    }
                }

                HAL_DBG_TRACE_MSG( "\n\n" );
                HAL_DBG_TRACE_INFO( "Transmission done\n" );
                uplink_sending = false;

                break;
            }

            case LR1121_MODEM_LORAWAN_EVENT_DOWN_DATA:
            {
                uint8_t rx_payload[LORAWAN_APP_DATA_MAX_SIZE] = { 0 };
                uint8_t rx_payload_size = 0;
                uint8_t rx_remaining = 0;

                lr1121_modem_downlink_metadata_t rx_metadata = { 0 };
                lr1121_modem_response_code_t rc;

                HAL_DBG_TRACE_MSG_COLOR(
                    "Event received: DOWNDATA\n\n",
                    HAL_DBG_TRACE_COLOR_BLUE
                );

                rc = lr1121_modem_get_downlink_data_size(
                    context,
                    &rx_payload_size,
                    &rx_remaining
                );

                if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
                {
                    HAL_DBG_TRACE_ERROR(
                        "Get downlink size failed, rc=%u\n",
                        ( unsigned int ) rc
                    );
                    break;
                }

                if( rx_payload_size > LORAWAN_APP_DATA_MAX_SIZE )
                {
                    HAL_DBG_TRACE_ERROR(
                        "Invalid downlink size: %u\n",
                        ( unsigned int ) rx_payload_size
                    );
                    break;
                }

                rc = lr1121_modem_get_downlink_data(
                    context,
                    rx_payload,
                    rx_payload_size
                );

                if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
                {
                    HAL_DBG_TRACE_ERROR(
                        "Get downlink data failed, rc=%u\n",
                        ( unsigned int ) rc
                    );
                    break;
                }

                rc = lr1121_modem_get_downlink_metadata(
                    context,
                    &rx_metadata
                );

                if( rc != LR1121_MODEM_RESPONSE_CODE_OK )
                {
                    HAL_DBG_TRACE_ERROR(
                        "Get downlink metadata failed, rc=%u\n",
                        ( unsigned int ) rc
                    );
                    break;
                }

                HAL_DBG_TRACE_PRINTF(
                    "Data received on port %u\n",
                    ( unsigned int ) rx_metadata.fport
                );

                HAL_DBG_TRACE_ARRAY(
                    "Received payload",
                    rx_payload,
                    rx_payload_size
                );

                HAL_DBG_TRACE_PRINTF(
                    "Remaining downlinks: %u\n",
                    ( unsigned int ) rx_remaining
                );

                break;
            }

            default:
            {
                HAL_DBG_TRACE_WARNING(
                    "Unhandled modem event: type=0x%02X, "
                    "data=0x%04X, missed=%u\n",
                    ( unsigned int ) current_event.event_type,
                    ( unsigned int ) current_event.data,
                    ( unsigned int ) current_event.missed_events_count
                );

                break;
            }
        }
    }
}

/*
 * GPIO button callback. Keep this interrupt callback short: only set the flag.
 * The main loop performs the modem operations.
 */
static void user_button_callback( void* context )
{
    ( void ) context;
    user_button_is_press = true;
}
